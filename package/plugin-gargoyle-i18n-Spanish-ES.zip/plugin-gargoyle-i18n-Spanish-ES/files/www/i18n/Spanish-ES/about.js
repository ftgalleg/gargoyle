﻿/*
 * UTF-8 (with BOM) Spanish-ES text strings for about.sh html elements
 */

abt.CSect="Créditos";
abt.EBishop="Fundador del proyecto, desarrollador principal de Gargoyle";
abt.PBixel="Implementado Control Activo de Congestión, así como muchas otras mejoras a QoS";
abt.AWronowski="Implementada funcionalidad Wake-on-LAN junto con varias mejoras/correcciones menores";
abt.CJackiewicz="Traducción al polaco, varias correcciones de errores, mejoras, plugins, compilaciones personalizadas en Polaco y soporte en idioma polaco través de su sitio web";
abt.PKarbowski="Implementadas numerosas correcciones de errores y mejoras de rendimiento";
abt.TButler="Implementadas varias mejoras para las tablas de visualización y botones de gran tamaño";
abt.IFedorenko="Implementada la inclusión del último commit realizado en Git en etiqueta predeterminada de la versión";
abt.BCoy="Aportadas varias sugerencias muy útiles sobre el diseño web y la aplicación de CSS para Gargoyle";
abt.FRiC="Aportada ayuda significativa en las pruebas de Gargoyle, particularmente en la funcionalidad de PPPoE";
abt.logo="El logo de Gargoyle ha sido derivado a partir de la fuente Gargoyle creada por Manfred Klein, quien ha dispuesto de manera gratuita para su utlización tanto comercial como no comercial";
abt.openwrt="La interfaz de Gargoyle es un front-end para el excelente firmware OpenWrt, y este proyecto no habría sido posible sin el arduo trabajo del equipo de OpenWrt";
abt.LSect="Licencia";
