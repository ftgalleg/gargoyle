﻿/*
 * UTF-8 (with BOM) Spanish-ES text strings for logread.sh html elements
 */

sylS.SLogs="Registros del Sistema";
sylS.Rfsh="Actualizar";
sylS.Load="Cargando Registros...";
