﻿/*
 * UTF-8 (with BOM) Spanish-ES text strings for webshell.sh html elements
 */

webS.Webs="Webshell";
webS.Cmd="Comando";
webS.Exe="Ejecutar";
webS.CmdWarn="¡No ejecute ningún comando interactivo o que nunca finalice!";
