﻿/*
 * UTF-8 (with BOM) English-EN text strings for hosts.sh html elements
 */

hostsStr.RefreshR="Frecuencia de actualización";
hostsStr.RInfo="Este valor especifica la frecuencia con la que se actualizan los datos en esta página";
hostsStr.CurrLeases="Asignaciones DHCP Actuales";
hostsStr.ConWifiHosts="Equipos inalámbricos conectados";
hostsStr.ActiveHosts="Equipos con conexiones activas";

//javascript
hostsStr.HostIP="IP del Equipo";
hostsStr.HostMAC="MAC del Equipo";
hostsStr.LeaseExp="Asignación Finaliza";
hostsStr.Signal="Señal";
hostsStr.ActiveConx="Conex. TCP Activas";
hostsStr.RecentConx="Conex. TCP Recientes";
hostsStr.UDPConx="Conex. UDP";
