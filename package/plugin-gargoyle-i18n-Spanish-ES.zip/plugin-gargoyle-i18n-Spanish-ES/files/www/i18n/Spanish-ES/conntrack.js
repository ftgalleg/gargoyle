﻿/*
 * UTF-8 (with BOM) Spanish-ES text strings for contrack.sh html elements
 */

connTS.CCSect="Conexiones Actuales";
connTS.RRate="Frecuencia de Actualización";
connTS.BUnt="Unidades del Ancho de Banda";
connTS.AtMxd="Auto (mixto)";
connTS.CnWarn="Las conexiones entre los equipos locales y el enrutador no son visualizadas.";
connTS.PrNm="Proto";
connTS.WLNm="Equipo WAN/ Equipo LAN";
connTS.UDNm="Bytes Subida/Descarga";
connTS.QSNm="QoS Subida/Descarga";
connTS.LPNm="Proto L7";
