﻿/*
 * UTF-8 (with BOM) English-EN text strings for webmon.sh html elements
 */

webmS.PrSect="Preferencias del Monitor Web";
webmS.EMon="Activar Monitor de Uso Web";
webmS.NumSt="Número de Sitios a Guardar";
webmS.NumSr="Número de Búsquedas a Guardar";
webmS.MnAH="Monitorear Todos los Equipos";
webmS.MnOnly="Monitorear Sólo los Siguientes equipos";
webmS.MnExcl="Excluir los Siguientes Equipos del Monitoreo";
webmS.SpcIP="Especifique IP o rango de IP";
webmS.RctSt="Sitios Visitados Recientemente";
webmS.RctSr="Búsquedas Web Recientes";
webmS.DlWD="Descargar Datos de Uso Web";
webmS.cmsep="Los datos son separados por comas";
webmS.dForm="[Hora de la última visita],[IP Local],[Dominio Visitado/Solicitud de Búsqueda]";
webmS.VSit="Dominios Visitados";
webmS.SRqst="Solicitudes de Búsqueda";
webmS.dCol=['Equipo Local', 'Hora de Último Acceso', 'Sitio Web'];
webmS.sCol=['Equipo Local', 'Hora de Último Acceso', 'Texto de Búsqueda'];
