﻿/*
 * UTF-8 (with BOM) Spanish-ES text strings for login hook for tor html elements
 */

torLS.tIP="Para su IP, Tor es";
torLS.tEnab="Activar Tor para su IP";
torLS.tDisa="Desactivar Tor para su IP";
torLS.IPErr="ERROR: Su IP no ha sido asignada por el servidor DHCP y no se encuentra configurada como una IP estática conocida\n\nConfiguración de Tor prohibida";
torLS.EqErr="ERROR: La asociación de Tor para cada IP se encuentra desactivada\n\nConfiguración de Tor prohibida";
torLS.EnabMsg="Se ha activado exitosamente Tor para su IP";
torLS.DisbMsg="Se ha desactivado exitosamente Tor para su IP";
