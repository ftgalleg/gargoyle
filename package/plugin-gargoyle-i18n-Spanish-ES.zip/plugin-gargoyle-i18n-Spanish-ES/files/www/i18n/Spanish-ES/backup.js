﻿/*
 * UTF-8 (with BOM) Spanish-ES text strings for backup.sh html elements
 */

bkS.CurrC="Realizar Copia de Seguridad de la Configuración Actual";
bkS.RestC="Restaurar Configuración Antigua";
bkS.DfltC="Restaurar Configuración por Defecto";
bkS.SelOF="Seleccionar Archivo de Configuración Antigua";

//javascript
bkS.SelCErr="ERROR: Debe seleccionar un archivo de configuración para restaurar.";
bkS.EraseWarn="Esto borrará completamente las configuraciones actuales y las reemplazará por otras nuevas del archivo de configuración seleccionado. ¿Está seguro que desea continuar?";
bkS.UpingC="Cargando Archivo de Configuración";
bkS.LdOrig="Cargando Archivo de Configuración Original";
bkS.FailErr="Restauración fallida. Asegúrese que el archivo cargado es un archivo de configuración válido de Gargoyle y vuelva a intentarlo.";
bkS.PrepBack="Preparación del Archivo de Copia de Seguridad";
