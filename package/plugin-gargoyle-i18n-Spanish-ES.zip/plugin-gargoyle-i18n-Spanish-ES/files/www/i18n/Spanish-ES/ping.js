﻿/*
 * UTF-8 (with BOM) English-EN text strings for ping_watchdog.sh html elements
 */

pingS.Pdog="ping Whatchdog";
pingS.EnbP="Activar Ping Whatchdog";
pingS.PgIP="Dirección IP a Realizar Ping";
pingS.IPAd="Dirección IP";
pingS.Intv="Intérvalo de Ping";
pingS.StDly="Retraso Inicial";
pingS.FlCnt="Recuento de Pings Fallidos";
pingS.Actn="Acción";
pingS.WRcon="Reconectar WAN";
pingS.Rbot="Reiniciar";
pingS.Rscp="Ejecutar script personalizado";
pingS.Scpt="Script";

//javascript
pingS.ScptErr="Debe agregar el script a ejecutar";
