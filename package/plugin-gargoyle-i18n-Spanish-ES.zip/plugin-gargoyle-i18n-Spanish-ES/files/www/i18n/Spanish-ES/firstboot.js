﻿/*
 * UTF-8 (with BOM) Spanish-ES text strings for firstboot.sh html elements
 */

fbS.ISSect="Configuración Inicial";
fbS.npass="Introduzca una nueva contraseña ahora";
fbS.NPass="Nueva Contraseña";
fbS.Stz="Seleccione su zona horaria";
fbS.Sla="Seleccione Idioma";
fbS.SSet="Guardar configuración";
fbS.ULngF="Cargar archivo de Idioma";

//javascript
fbS.nopsErr="ERROR: Debe especificar una contraseña";
fbS.pseqErr="ERROR: Las contraseñas no coinciden";
