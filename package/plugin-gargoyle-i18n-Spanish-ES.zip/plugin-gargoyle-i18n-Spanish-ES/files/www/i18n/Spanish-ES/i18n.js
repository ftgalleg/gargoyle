﻿/*
 * UTF-8 (with BOM) Spanish-ES text strings for i18n-firstoot.sh & languages.sh html elements
 */

intS.LMSect="Administrador de idiomas";

//i18n.js javascript
intS.Lang="Idioma";
intS.Desc="Descripción";
intS.Upld="Subir";
intS.UpMsg="Cargando Archivo de idioma";
intS.Acv8="Activar";
intS.Actv="Activo";
intS.Instd="Instalado";
