﻿/*
 * UTF-8 (with BOM) Spanish-ES text strings for reboot.sh html elements
 */

rbS.RbSect="Reiniciar";
rbS.SchRb="Reinicio Programado";
rbS.NoSch="Sin Reinicio Programado";
rbS.RbSch="Reinicio Programado";
rbS.WillR="El Enrutador se Reiniciará";
rbS.EDay="Todos los Días";
rbS.EWek="Cada Semana";
rbS.EMnh="Cada Mes";
rbS.RDay="Día de Reinicio";
rbS.RHr="Hora de Reinicio";

//javascript
rbS.SysR="El Sistema Se Está Reiniciando";
rbS.Digs="o";
rbS.LD1s="er";
rbS.LD2s="do";
rbS.LD3s="er";
rbS.DaysWArr=["domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"];
