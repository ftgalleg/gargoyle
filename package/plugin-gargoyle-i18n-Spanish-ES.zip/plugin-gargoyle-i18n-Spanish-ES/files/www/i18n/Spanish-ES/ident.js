﻿/*
 * UTF-8 (with BOM) Spanish-ES text strings for identification.sh html elements
 */

idtS.IdSect="Identificación";
idtS.Domn="Dominio";
idtS.DevNm="Nombre del Dispositivo";
