﻿/*
 * UTF-8 (with BOM) Spanish-ES text strings for routing.sh html elements
 */

rtgS.ARSect="Rutas Activas";
rtgS.SRSect="Rutas Estáticas";
rtgS.ASRte="Agregar Ruta Estática";
rtgS.CSRSect="Rutas Estáticas Actuales";
rtgS.ESSect="Editar Ruta Estática";

//javascript & template
rtgS.Dstn="Destino";
rtgS.DstnM="Destino/Máscara";
rtgS.ItfN="Interfaz (Red)";
rtgS.Itfc="Interfaz";
rtgS.Ntwk="Red";
rtgS.Gtwy="Puerta de Enlace";
rtgS.Mtrc="Métrica";
rtgS.AErr="No se pudo agregar la fila.";
rtgS.SRErr="No se pudo actualizar la ruta estática.";
