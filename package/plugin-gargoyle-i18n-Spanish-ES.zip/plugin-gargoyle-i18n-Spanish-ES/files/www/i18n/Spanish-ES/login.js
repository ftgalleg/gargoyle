﻿/*
 * UTF-8 (with BOM) English-EN text strings for login.sh html elements
 */

logS.LSect="Iniciar Sesión";
logS.EAdmP="Introduzca la Contraseña de Administrador";
logS.YQot="Su Cuota";
logS.NQot="Cuota de la Red Entera";
logS.CTime="Fecha y Hora Actual";

//javascript
logS.passErr="ERROR: Debe introducir una contraseña";
logS.Lging="Inicio de Sesión";
logS.SExp="Sesión Expirada";
logS.InvP="Contraseña no válida";
logS.LOut="Sesión Finalizada";
logS.Qnam=["total subida+descarga", "descarga", "subida" ];
logS.of="de";
logS.fQuo="para Cuota";
logS.husd="se ha utilizado";
logS.qusd="cuota se ha utilizado";
