﻿/*
 * UTF-8 (with BOM) Spanish-ES text strings for conlimits.sh html elements
 */

connLS.CLSect="Límites de Conexión";
connLS.MaxC="Conexiones máximas";
connLS.TTout="Tiempo de espera de TCP";
connLS.UTout="Tiempo de espera de UDP";
connLS.max="máx";
