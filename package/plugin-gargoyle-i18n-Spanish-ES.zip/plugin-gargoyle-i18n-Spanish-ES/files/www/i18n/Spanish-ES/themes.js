﻿/*
 * UTF-8 (with BOM) Spanish-ES text strings for themes.sh html elements
 */

thmS.TMSect="Administrador de temas";
thmS.Thm="Tema";
