﻿/*
 * UTF-8 (with BOM) Spanish-ES text strings for printers.sh html elements
 */

prnt.Attch="Impresoras USB Conectadas";
prnt.NoPrnt="No hay impresoras USB conectadas actualmente al enrutador.";
prnt.ConnU="se conecta mediante USB.";
prnt.ConnIP="Puede conectarse a su impresora en la IP";
prnt.JetProto="mediante el protocolo JetDirect de HP.";
