﻿/* UTF-8 (with BOM) strings for gargoyle_header_footer */

ghf.title="Gargoyle Utilidad de Administración del Router";
ghf.desc="Utilidad de Administración del Router";
ghf.devn="Nombre del Dispositivo";
ghf.waits="Por favor, espere mientras se aplica la configuración";
